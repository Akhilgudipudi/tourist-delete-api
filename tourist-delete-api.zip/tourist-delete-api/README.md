# Tourist Delete API

A small Spring Boot REST API demonstrating deletion of a tourist record by ID,
request-header token validation, and database exception handling.

## Technologies
- Java 17
- Spring Boot 3.3.5
- Spring Web
- Spring Data JPA
- H2 in-memory database
- Swagger UI / OpenAPI
- Maven

## Run the project

```bash
mvn spring-boot:run
```

The application starts at `http://localhost:8080`.

## API

### Delete a tourist

```http
DELETE http://localhost:8080/api/tourists/1
Token: ABC123
```

Successful response: `200 OK`

```text
Tourist Record Deleted Successfully
```

Invalid or missing token: `500 Internal Server Error`

```text
Deletion Failed: Token Error
```

If the ID does not exist: `404 Not Found`.

> For this exam exercise, an invalid token returns HTTP 500 to match the
> assignment's stated expected output. In production APIs, use HTTP 401
> (Unauthorized) for invalid authentication tokens.

## Swagger UI

Open `http://localhost:8080/swagger-ui/index.html`.

For the DELETE endpoint, add the request header `Token` with value `ABC123`.

## H2 database console

Open `http://localhost:8080/h2-console` and use:

- JDBC URL: `jdbc:h2:mem:touristdb`
- User Name: `sa`
- Password: (leave blank)

The application inserts two sample tourist records at startup:
- ID 1 — Akhil, Hyderabad
- ID 2 — Ravi, Chennai

## Project structure

```text
src/main/java/com/example/touristapi/
├── TouristApiApplication.java
├── config/
│   └── WebConfig.java
├── controller/
│   └── TouristController.java
├── exception/
│   └── GlobalExceptionHandler.java
├── interceptor/
│   └── TokenInterceptor.java
├── model/
│   └── Tourist.java
├── repository/
│   └── TouristRepository.java
└── service/
    └── TouristService.java
```
