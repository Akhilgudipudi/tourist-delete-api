package com.example.touristapi.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class TokenInterceptor implements HandlerInterceptor {

    private static final String VALID_TOKEN = "ABC123";

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {

        if (!"DELETE".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        String token = request.getHeader("Token");

        if (VALID_TOKEN.equals(token)) {
            return true;
        }

        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        response.setContentType("text/plain");
        response.getWriter().write("Deletion Failed: Token Error");
        return false;
    }
}
