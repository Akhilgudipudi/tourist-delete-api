package com.example.touristapi;

import com.example.touristapi.model.Tourist;
import com.example.touristapi.repository.TouristRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class TouristApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(TouristApiApplication.class, args);
    }

    @Bean
    CommandLineRunner loadSampleData(TouristRepository repository) {
        return args -> {
            repository.save(new Tourist("Akhil", "Hyderabad"));
            repository.save(new Tourist("Ravi", "Chennai"));
        };
    }
}
