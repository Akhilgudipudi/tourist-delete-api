package com.example.touristapi.controller;

import com.example.touristapi.service.TouristService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/tourists")
public class TouristController {

    private final TouristService service;

    public TouristController(TouristService service) {
        this.service = service;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTourist(@PathVariable Long id) {
        service.deleteTourist(id);
        return ResponseEntity.ok("Tourist Record Deleted Successfully");
    }
}
