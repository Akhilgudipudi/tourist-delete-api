package com.example.touristapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TouristApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
